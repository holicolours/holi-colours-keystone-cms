import { integer, relationship, select, text, timestamp, virtual } from '@keystone-6/core/fields';
import { graphql, list } from '@keystone-6/core';
import { rules, isSignedIn } from '../access';

export const Review = list({
  // access: {
  //   operation: {
  //     create: isSignedIn,
  //   },
  //   filter: {
  //     query: rules.canReadProducts,
  //     update: rules.canManageProducts,
  //     delete: rules.canManageProducts,
  //   },
  // },
  ui: {
    listView: {
      initialColumns: ['title', 'rating', 'customerName', 'createdOn'],
      initialSort: {
        field: 'createdOn',
        direction: 'DESC'
      }
    },
  },
  fields: {
    title: text({ validation: { isRequired: true } }),
    message: text({ 
      validation: { isRequired: true },
      ui: {
        displayMode: 'textarea'
      } 
    }),
    rating: select({
      options: [
        { label: 'One Star', value: '1' },
        { label: 'Two Star', value: '2' },
        { label: 'Three Star', value: '3' },
        { label: 'Four Star', value: '4' },
        { label: 'Five Star', value: '5' },
      ],
      ui: {
        displayMode: 'select',
      },
    }),
    product: relationship({
      ref: 'Product.reviews',
    }),
    customerName: text({ validation: { isRequired: true } }),
    customerEmail: relationship({
      ref: 'Customer.reviews',
      ui: {
        itemView: { fieldMode: 'read' }
      }
    }),
    createdOn: timestamp({
      ui: {
        itemView: { fieldMode: 'read' }
      }
    }),
  },
});