import { text, relationship, checkbox, timestamp } from '@keystone-6/core/fields';
import { list } from '@keystone-6/core';
import { rules, isSignedIn } from '../access';
var slugify = require('slugify');

export const Category = list({
  // access: {
  //   operation: {
  //     create: isSignedIn,
  //   },
  //   filter: {
  //     query: rules.canReadProducts,
  //     update: rules.canManageProducts,
  //     delete: rules.canManageProducts,
  //   },
  // },
  ui: {
    listView: {
      initialColumns: ['name', 'parentCategories', 'childCategories'],
    },
  },
  fields: {
    name: text({
      validation: {
        isRequired: true,
      },
      isIndexed: 'unique'
    }),
    slug: text({
      isIndexed: 'unique',
      ui: {
        createView: {
          fieldMode: 'hidden'
        },
        itemView: {
          fieldMode: 'hidden'
        }
      }
    }),
    parentCategories: relationship({ ref: 'Category.childCategories', many: true }),
    childCategories: relationship({ ref: 'Category.parentCategories', many: true }),
    featureInHomePage: checkbox({
      defaultValue: false,
    }),
    products: relationship({
      ref: 'Product.categories',
      many: true,
      ui: {
        createView: { fieldMode: 'hidden' }
      }
    }),
    // creationDate: timestamp({
    //   defaultValue: new Date().toISOString(),
    //   ui: {
    //     createView: { fieldMode: 'hidden' },
    //     itemView: { fieldMode: 'read' },
    //   }
    // }),
    // lastUpdatedDate: timestamp({
    //   defaultValue: new Date().toISOString(),
    //   ui: {
    //     createView: { fieldMode: 'hidden' },
    //     itemView: { fieldMode: 'read' },
    //   }
    // }),
  },
  hooks: {
    resolveInput: async ({
      listKey,
      operation,
      inputData,
      item,
      resolvedData,
      context,
    }) => {
      const { name } = resolvedData;
      if (operation == 'create') {
        // resolvedData.creationDate = new Date().toISOString();
      }
      if (operation == 'create' || operation == 'update') {
        if (name) {
          resolvedData.slug = slugify(name.toLowerCase());
        }
        // resolvedData.lastUpdatedDate = new Date().toISOString();
      }
      return resolvedData;
    },
    validateInput: async ({
      resolvedData,
      addValidationError,
    }) => {
      const { name } = resolvedData;
      if (name) {
        let format = /[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
        if (format.test(name)) {
          addValidationError('Category name can\'t contain special charecters!');
        }
      }
    },
  },
});