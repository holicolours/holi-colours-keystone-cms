import { integer, relationship, timestamp } from '@keystone-6/core/fields';
import { list } from '@keystone-6/core';
import { rules, isSignedIn } from '../access';

export const OutboundStock = list({
  // access: {
  //   operation: {
  //     create: isSignedIn,
  //   },
  //   filter: {
  //     query: rules.canReadProducts,
  //     update: rules.canManageProducts,
  //     delete: rules.canManageProducts,
  //   },
  // },
  ui: {
    isHidden: true,
  },
  fields: {
    sku: relationship({
      ref: 'Stock.outboundStock',
      many: false,
    }),
    stockQuantity: integer({ validation: { isRequired: true } }),
    orderItem: relationship({
      ref: 'OrderItem',
      many: false,
    }),
  },
});