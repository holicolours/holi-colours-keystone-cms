import { integer, relationship, text, timestamp } from '@keystone-6/core/fields';
import { list } from '@keystone-6/core';
import { rules, isSignedIn } from '../access';

export const Stock = list({
  // access: {
  //   operation: {
  //     create: isSignedIn,
  //   },
  //   filter: {
  //     query: rules.canReadProducts,
  //     update: rules.canManageProducts,
  //     delete: rules.canManageProducts,
  //   },
  // },
  ui: {
    labelField: 'sku'
  },
  fields: {
    sku: text({
      label: 'SKU',
      isIndexed: 'unique',
      validation: { isRequired: true },
      db: { isNullable: false },
    }),
    product: relationship({
      ref: 'Product',
      ui: {
        hideCreate: true,
        itemView: { fieldMode: 'read'}
      },
    }),
    variant: relationship({
      ref: 'ProductVariant.stock',
      ui: {
        hideCreate: true,
        itemView: { fieldMode: 'read'}
      },
    }),
    inboundStock: relationship({
      ref: 'InboundStock.sku',
      many: false,
    }),
    outboundStock: relationship({
      ref: 'OutboundStock.sku',
      many: false,
    }),
    vendor: relationship({
      ref: 'Vendor.skus',
      many: false,
    }),
  },
});