import { integer, relationship, timestamp } from '@keystone-6/core/fields';
import { list } from '@keystone-6/core';
import { rules, isSignedIn } from '../access';

export const InboundStock = list({
  // access: {
  //   operation: {
  //     create: isSignedIn,
  //   },
  //   filter: {
  //     query: rules.canReadProducts,
  //     update: rules.canManageProducts,
  //     delete: rules.canManageProducts,
  //   },
  // },
  ui: {
    isHidden: true,
  },
  fields: {
    sku: relationship({
      ref: 'Stock.inboundStock',
      many: false,
    }),
    stockQuantity: integer({ validation: { isRequired: true } }),
    dateOfPurchase: timestamp({ validation: { isRequired: true } }),
  },
});