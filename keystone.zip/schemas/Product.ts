import { select, text, relationship, virtual, json, integer, timestamp } from '@keystone-6/core/fields';
import { document } from '@keystone-6/fields-document';
import { graphql, list } from '@keystone-6/core';
import { rules, isSignedIn } from '../access';
var slugify = require('slugify');
var firebase = require('firebase-admin');

const serviceAccount = {
  "type": "service_account",
  "project_id": "holi-colours-jewellery",
  "private_key_id": "a58823557e808ef91ec120c40c7e14354e6b18e7",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCqpsbWfiAZKZ47\nouOz4E4BJ1Zg4v2FbsfupZqiJFTbQZY2qPYFITnuVaFyrHZ8KtymgKi34+scsprk\nnG5Kx0KAqSALHNnAIp8xmB2ajmbSwGNY4t5sh+FpehYlP00FP/hYlqMNG+HCGczD\nbI75CUSOXW5O81Vy5tMTiSlDnNcSacXmZFctJ6wFN5gMRuR3Hb6na6NQGD9oRfzt\n0VnFfG+w8N8UIgt+7Onsuga5P+XDBeV2mGWGQE9qad6X6u74Hi4pdlBfnWwCz3O5\nCq7nh6FqMJqll5TxaRGC86RkqZ+Tg7GRwu0P738eh57lG5dbYS1yMg1aOMv4ChBK\nSs/sDK3TAgMBAAECggEAGyabviak/rvjZAOfjM/kOUTD9nhG88LTZoHMn31+TsAZ\noSqysdA+gk/3duI/m7PKFWek8FT/5Dn6cOL+nUEksIm4AmydrHcVsvNLynpbm65m\nYA8Aam4YDAsTmOuAWpR588ZLvNsxyQsHzBPqj27NDIWK9l66uqRE8vfAq/Q5N8F/\n2+aeEDytQpNQUHsCKCZ638TqWBdxPEVxMzCJ5UT/U2CaeX0Ejy1dWWmFc3z+FuXq\nDVLTlWAfI3tIaYWni+xMShQehMmPbN0+9Phls6YcuEbtlnneFGxm4x2EK28t3gHT\nUAKJ1/pvg+obx8Uodva4O3FqfVbV3euS6F11U/3ncQKBgQDaLvfLNlLhLM59k4j+\nA1KhxCLHrW39jpKtxW5N3AR6RPoVlJMq/6qBbKUrmXTWc3mVcHcqt2JlcNjw5Ruv\nAZ61GIivcrUoNIF7xgFNzuHmR41y2i58aES1escAJR9L2MhQi1oxwGbyavtomaei\ndG1jOGjfBUzWetHdKKWTU9rXyQKBgQDIOsN8KBBLGNHqxdnALCLV1EnpMBAwCG4c\ncW842KD4SPrK64YvOrzVlriksWXq2q6jE4m5Sw5qVzIc16jyliL1BKRzNmm4cLjF\nyPiRx/Ng+NvsEzaBfKInjWgAHyXtkMGVLUDjUTIweg6WvJBbbUUTXG/W1e7AtYe6\nC1GroWueuwKBgBqXDMXsSe99WXD+cPycBQ8H60Ewhq4XGRMqc4XzoWwRSfUlVUYx\nQGNjjUGiAxY7nn6y5SMElG5OcXHySgxrAx+I7OeM8D0FIR6ng/MqmmdJIxjzNCUf\nQ/hmDSicXZMNyWPfh892ZlV26krWJxLqY4ZrEoTTjYi6ESeF05//4TTZAoGAXxWY\n05Lq+d6VgRnnqBzNhiHD35rVdRnrwFIV8Tbeakmt30Mte6w3FG74zCz6KyciG4sh\nsf50oAc8Yvn+3wRxIU3NEnFajx3ogPRJJmF/sCM9vMP69E7Nal76bmRcTI6bf034\nLHrYjLDJ0MdG/kPLs8AH1EvPj3AlPjI13H1RcBUCgYAwCrBjqURfZ9Jd9+wFCFQS\ne7kHFQ0ITBn8pO1Zt604DRcn9GaRkLfo3IBuYbume5tvmebQ5yPgJMyaAEmOktim\nDJbPXnVx7WdaHniOKpFQ3xzCZZq6mFDsVflSeHvZ20cGpICZyuVVe6yLKtdf63yE\nMyUKkR2lMLusYGD4zqsc1w==\n-----END PRIVATE KEY-----\n",
  "client_email": "firebase-adminsdk-anxtl@holi-colours-jewellery.iam.gserviceaccount.com",
  "client_id": "109764840705438007823",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-anxtl%40holi-colours-jewellery.iam.gserviceaccount.com"
};

export const cloudinary = {
  cloudName: process.env.CLOUDINARY_CLOUD_NAME || 'fake',
  apiKey: process.env.CLOUDINARY_KEY || 'fake',
  apiSecret: process.env.CLOUDINARY_SECRET || 'fake',
  folder: 'products',
};

export const Product = list({
  // access: {
  //   operation: {
  //     create: isSignedIn,
  //   },
  //   filter: {
  //     query: rules.canReadProducts,
  //     update: rules.canManageProducts,
  //     delete: rules.canManageProducts,
  //   },
  // },
  ui: {
    listView: {
      initialColumns: ['name', 'status', 'sku', 'price', 'categories', 'options', 'variants'],
    },
  },
  fields: {
    name: text({
      validation: {
        isRequired: true,
      },
      isIndexed: 'unique'
    }),
    slug: text({
      // validation: {
      //   isRequired: true,
      // },
      isIndexed: 'unique',
      ui: {
        createView: {
          fieldMode: 'hidden'
        },
        itemView: {
          fieldMode: 'hidden'
        }
      }
    }),
    url: virtual({
      label: 'URL',
      field: graphql.field({
        type: graphql.String,
        resolve(item) {
          let product = item as any;
          return `https://holicoloursjewellery.in/products/${product.slug}`;
        },
      }),
    }),
    status: select({
      options: [
        { label: 'Draft', value: 'DRAFT' },
        { label: 'Published', value: 'PUBLISHED' },
      ],
      defaultValue: 'DRAFT',
      ui: {
        displayMode: 'segmented-control',
        createView: { fieldMode: 'hidden' },
      },
    }),
    sku: integer({
      label: 'SKU',
      ui: {
        createView: { fieldMode: 'hidden' },
        itemView: { fieldMode: 'read' },
      }
    }),
    description: text({
      ui: {
        displayMode: 'textarea',
        createView: { fieldMode: 'hidden' },
      },
    }),
    additionalInformation: document({
      formatting: {
        inlineMarks: {
          bold: true,
          italic: true,
          underline: true,
          strikethrough: true,
          superscript: true,
          subscript: true,
        },
        listTypes: true,
        alignment: true,
        headingLevels: [1, 2, 3, 4, 5, 6],
        blockTypes: {
          blockquote: true,
        },
        softBreaks: true,
      },
      links: true,
      dividers: true,
      label: 'Additional Information',
      ui: {
        createView: { fieldMode: 'hidden' },
      }
    }),
    options: relationship({
      ref: 'ProductOption.product',
      ui: {
        displayMode: 'cards',
        cardFields: ['option'],
        inlineCreate: { fields: ['optionName', 'optionValues'] },
        inlineEdit: { fields: ['optionName', 'optionValues'] },
        // inlineConnect: false,
        // linkToItem: true,
        createView: { fieldMode: 'hidden' },
      },
      many: true
    }),
    defaultVariantOptions: relationship({
      ref: 'ProductOptionValue',
      many: true,
      ui: {
        createView: { fieldMode: 'hidden' }
      }
    }),
    categories: relationship({
      ref: 'Category.products',
      many: true,
      ui: {
        displayMode: 'select',
        createView: { fieldMode: 'hidden' },
      },
    }),
    tags: relationship({
      ref: 'Tag.products',
      many: true,
      ui: {
        createView: { fieldMode: 'hidden' },
      },
    }),
    variants: relationship({
      ref: 'ProductVariant.product',
      ui: {
        displayMode: 'select',
        createView: { fieldMode: 'hidden' },
        // cardFields: ['title', 'image', 'regularPrice', 'stock'],
        // inlineCreate: { fields: ['title', 'enabled', 'defaultVariant', 'image', 'regularPrice', 'length', 'width', 'weight', 'height', 'stock'] },
        // inlineEdit: { fields: ['title', 'enabled', 'defaultVariant', 'image', 'regularPrice', 'length', 'width', 'weight', 'height', 'stock'] },
        // inlineConnect: false,
        // linkToItem: true
      },
      many: true
    }),
    stock: virtual({
      field: graphql.field({
        type: graphql.Int,
        resolve() {
          return 0;
        },
      }),
    }),
    accessories: relationship({
      ref: 'Accessory.products',
      many: true,
      ui: {
        createView: { fieldMode: 'hidden' },
      }
    }),
    reviews: relationship({
      ref: 'Review.product',
      many: true,
      ui: {
        createView: { fieldMode: 'hidden' },
      }
    }),
    price: virtual({
      field: graphql.field({
        type: graphql.String,
        resolve(item, args, context) {
          let priceRange = '';
          let product = item as any;
          priceRange = context.query.Product.findOne({
            where: { id: product.id },
            query: 'variants { regularPrice }'
          }).then((resp) => {
            let priceList = resp.variants.map((v: { regularPrice: any; }) => v.regularPrice);
            if (priceList.length == 0) {
              return '-';
            }
            let min = Math.min(...priceList);
            let max = Math.max(...priceList);
            if (min == max) {
              return '₹' + min;
            } else {
              return '₹' + min + ' - ₹' + max;
            }
          }) as any;
          return priceRange;
        },
      }),
      ui: {
        itemView: {
          fieldMode: 'hidden'
        }
      }
    }),
    orders: relationship({ 
      ref: 'Order.products', 
      many: true,
      ui: {
        createView: { fieldMode: 'hidden' },
        displayMode: 'count',
      }
    }),
    creationDate: timestamp({
      ui: {
        createView: { fieldMode: 'hidden' },
        itemView: { fieldMode: 'read' },
      }
    }),
    lastUpdatedDate: timestamp({
      ui: {
        createView: { fieldMode: 'hidden' },
        itemView: { fieldMode: 'read' },
      }
    }),
  },
  hooks: {
    resolveInput: async ({
      listKey,
      operation,
      inputData,
      item,
      resolvedData,
      context,
    }) => {
      console.log(resolvedData);
      const { name, categories } = resolvedData;
      if (operation == 'create' || operation == 'update') {
        if (name) {
          resolvedData.slug = slugify(name.toLowerCase());
        }
        resolvedData.lastUpdatedDate = new Date().toISOString();
      }
      if (operation == 'create') {
        resolvedData.creationDate = new Date().toISOString();
        let app;

        if (!firebase.apps.length) {
            app = firebase.initializeApp({
                credential: firebase.credential.cert(serviceAccount),
                databaseURL: "https://holi-colours-jewellery-default-rtdb.asia-southeast1.firebasedatabase.app/"
            });
        }

        let productSequence = await firebase.database().ref().child("sequence").child("products")
        .transaction(function (currentValue: any) {
            return (currentValue || 0) + 1;
        });
        resolvedData.sku = productSequence.snapshot.val();

        firebase.database().goOffline();
        app.delete();
      }
      // if (operation == 'create') {
      //   if (!categories) {
      //     resolvedData.categories = {
      //       set: undefined,
      //       disconnect: undefined,
      //       connect: [{ id: 'cl084v8q70389yopbq4hwvnl8' }]
      //     };
      //   }
      // }
      // if (categories && categories.connect) {
      //   console.log(categories.connect);
      // }
      return resolvedData;
    },
    validateInput: async ({
      resolvedData,
      addValidationError,
    }) => {
      const { name } = resolvedData;
      if (name) {
        let format = /[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
        if (format.test(name)) {
          addValidationError('Product name can\'t contain special charecters!');
        }
      }
    },
    afterOperation: ({ operation, item }) => {
      // console.log(item);
    }
  },
});