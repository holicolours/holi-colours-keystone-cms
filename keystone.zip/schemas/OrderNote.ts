import { integer, text, relationship, timestamp } from '@keystone-6/core/fields';
import { list } from '@keystone-6/core';
import { isSignedIn, rules } from '../access';
import { cloudinaryImage } from '@keystone-6/cloudinary';

export const OrderNote = list({
  access: {
    operation: {
      create: isSignedIn,
      update: () => false,
      delete: () => false,
    },
    filter: {
      query: rules.canManageOrderItems,
    },
  },
  ui: {
    isHidden: true,
    labelField: 'note',
    listView: {
      initialColumns: ['note', 'date'],
    },
  },
  fields: {
    order: relationship({
      ref: 'Order.notes',
      ui: {
        itemView: { fieldMode: 'read' }
      }
    }),
    note: text({ 
      validation: { isRequired: true },
      ui: {
        itemView: { fieldMode: 'read' }
      } 
    }),
    date: timestamp({
      ui: {
        itemView: { fieldMode: 'read' }
      }
    }),
  },
});