import { integer, text, relationship } from '@keystone-6/core/fields';
import { list } from '@keystone-6/core';
import { isSignedIn, rules } from '../access';
import { cloudinaryImage } from '@keystone-6/cloudinary';

export const OrderItem = list({
  access: {
    operation: {
      create: isSignedIn,
      update: () => false,
      delete: () => false,
    },
    filter: {
      query: rules.canManageOrderItems,
    },
  },
  ui: {
    isHidden: true,
    labelField: 'name',
    listView: {
      initialColumns: ['name', 'image', 'variant', 'sku', 'quantity', 'unitPrice', 'total'],
    },
  },
  fields: {
    order: relationship({ ref: 'Order.items' }),
    name: text({ validation: { isRequired: true } }),
    image: cloudinaryImage({
      cloudinary: {
        cloudName: process.env.CLOUDINARY_CLOUD_NAME || 'fake',
        apiKey: process.env.CLOUDINARY_KEY || 'fake',
        apiSecret: process.env.CLOUDINARY_SECRET || 'fake',
        folder: 'Order Items',
      }
    }),
    variant: text(),
    sku: text({ 
      validation: { isRequired: true },
      label: 'SKU'
    }),
    quantity: integer(),
    unitPrice: integer(),
    total: integer(),
  },
});