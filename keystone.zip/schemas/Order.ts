import { integer, text, relationship, virtual, select, timestamp } from '@keystone-6/core/fields';
import { list, graphql } from '@keystone-6/core';
import { isSignedIn, rules } from '../access';
import formatMoney from '../lib/formatMoney';

const uiHidden = 'hidden';
const uiReadOnly = 'read';

export const Order = list({
  access: {
    operation: {
      create: isSignedIn,
      update: isSignedIn,
      delete: () => false,
    },
    filter: { query: rules.canOrder },
  },
  ui: {
    labelField: 'orderNumber',
    listView: {
      initialColumns: ['orderNumber', 'orderDate', 'status', 'items', 'total', 'customerFirstName'],
      initialSort: {
        field: 'orderNumber',
        direction: 'DESC'
      }
    },
  },
  fields: {
    // label: virtual({
    //   field: graphql.field({
    //     type: graphql.String,
    //     resolve(item) {
    //       return `${formatMoney((item as any).total)}`;
    //     },
    //   }),
    // }),
    orderNumber: text({
      ui: { itemView: { fieldMode: uiReadOnly } }
    }),
    orderDate: timestamp({
      ui: {
        itemView: { fieldMode: uiReadOnly }
      }
    }),
    status: select({
      options: [
        { label: 'Pending payment', value: 'PP' },
        { label: 'Payment failed', value: 'PF' },
        { label: 'On hold', value: 'OH' },
        { label: 'Processing', value: 'PR' },
        { label: 'Dispatched', value: 'DI' },
        { label: 'Completed', value: 'CO' },
        { label: 'Cancelled', value: 'CA' },
      ],
      defaultValue: 'PP',
      ui: {
        displayMode: 'select',
        createView: { fieldMode: 'hidden' },
      },
    }),
    products: relationship({ 
      ref: 'Product.orders', 
      many: true,
      ui: {
        hideCreate: true,
        displayMode: 'select',
        itemView: { fieldMode: uiReadOnly }
      }
    }),
    items: relationship({ 
      ref: 'OrderItem.order', 
      many: true,
      ui: {
        hideCreate: true,
        displayMode: 'select',
        itemView: { fieldMode: uiReadOnly }
      }
    }),
    subTotal: integer({
      ui: {
        itemView: { fieldMode: uiReadOnly }
      }
    }),
    shippingMethod: text({
      ui: {
        itemView: { fieldMode: uiReadOnly }
      }
    }),
    shippingCharge: integer({
      ui: {
        itemView: { fieldMode: uiReadOnly }
      }
    }),
    discount: integer({
      ui: {
        itemView: { fieldMode: uiReadOnly }
      }
    }),
    total: integer({
      ui: {
        itemView: { fieldMode: uiReadOnly }
      }
    }),
    customerFirstName: text({
      ui: { itemView: { fieldMode: uiReadOnly } }
    }),
    customerLastName: text({
      ui: { itemView: { fieldMode: uiReadOnly } }
    }),
    customerEmail: relationship({
      ref: 'Customer.orders',
      ui: {
        itemView: { fieldMode: uiReadOnly }
      }
    }),
    customerPhoneNumber: text({
      ui: {
        itemView: { fieldMode: uiReadOnly }
      }
    }),
    customerAlternatePhoneNumber: text({
      ui: {
        itemView: { fieldMode: uiReadOnly }
      }
    }),
    shipToAddress: virtual({
      field: graphql.field({
        type: graphql.String,
        resolve(item) {
          let order = item as any;
          let address = order.shipToAddress1
          + ", "
          + order.shipToAddress2
          + ', '
          + order.shipToCity
          + ' - '
          + order.shipToPostalCode
          + ', '
          + order.shipToState
          + ', '
          + order.shipToCountry;
          return address;
        },
      }),
    }),
    shipToAddress1: text({
      ui: {
        itemView: { fieldMode: uiHidden }
      }
    }),
    shipToAddress2: text({
      ui: {
        itemView: { fieldMode: uiHidden }
      }
    }),
    shipToCity: text({
      ui: {
        itemView: { fieldMode: uiHidden }
      }
    }),
    shipToState: text({
      ui: {
        itemView: { fieldMode: uiHidden }
      }
    }),
    shipToCountry: text({
      ui: {
        itemView: { fieldMode: uiHidden }
      }
    }),
    shipToPostalCode: text({
      ui: {
        itemView: { fieldMode: uiHidden }
      }
    }),
    notes: relationship({ 
      ref: 'OrderNote.order', 
      many: true,
      ui: {
        displayMode: 'cards',
        cardFields: ['note', 'date'],
        inlineCreate: { fields: ['note'] },
        inlineConnect: false,
        linkToItem: true
      }
    }),
  },
});