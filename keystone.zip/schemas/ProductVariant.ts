import { integer, select, text, relationship, float, virtual } from '@keystone-6/core/fields';
import { cloudinaryImage } from '@keystone-6/cloudinary';
import { graphql, list } from '@keystone-6/core';
import { rules, isSignedIn } from '../access';

export const cloudinary = {
  cloudName: process.env.CLOUDINARY_CLOUD_NAME || 'fake',
  apiKey: process.env.CLOUDINARY_KEY || 'fake',
  apiSecret: process.env.CLOUDINARY_SECRET || 'fake',
  folder: 'products',
};

function getPrice(variant: any) {
  let price;
  if (variant.salePrice) {
    price = variant.salePrice;
  } else {
    price = variant.regularPrice;
  }
  return price;
}

export const ProductVariant = list({
  // access: {
  //   operation: {
  //     create: isSignedIn,
  //   },
  //   filter: {
  //     query: rules.canReadProducts,
  //     update: rules.canManageProducts,
  //     delete: rules.canManageProducts,
  //   },
  // },
  ui: {
    labelField: 'title',
    isHidden: true,
    listView: {
      initialColumns: ['title', 'status', 'image', 'price', 'status'],
    },
  },
  fields: {
    product: relationship({
      ref: 'Product.variants',
      ui: {
        hideCreate: true,
        createView: { fieldMode: 'hidden' },
        itemView: { fieldMode: 'read' }
      }
    }),
    options: relationship({
      ref: 'ProductOptionValue',
      many: true
    }),
    title: virtual({
      field: graphql.field({
        type: graphql.String,
        resolve(item, args, context) {
          let variantTitle = '';
          let variant = item as any;
          variantTitle = context.query.ProductVariant.findOne({
            where: { id: variant.id },
            query: 'options { optionValue }'
          }).then((value) => {
            let title = value.options.map((v: { optionValue: any; }) => v.optionValue).join(" x ");
            return title ? title : 'Simple Product';
          }) as any;
          return variantTitle;
        },
      }),
    }),
    status: select({
      options: [
        { label: 'Draft', value: 'DRAFT' },
        { label: 'Published', value: 'PUBLISHED' },
      ],
      defaultValue: 'DRAFT',
      ui: {
        displayMode: 'segmented-control',
        createView: { fieldMode: 'hidden' },
      },
    }),
    description: text({
      ui: {
        displayMode: 'textarea',
      },
    }),
    image: cloudinaryImage({
      cloudinary,
      label: 'Image',
    }),
    regularPrice: integer({ validation: { isRequired: true } }),
    salePrice: integer(),
    price: virtual({
      field: graphql.field({
        type: graphql.Int,
        resolve(item, args, context) {
          let variant = item as any;
          return getPrice(variant);
        },
      }),
      ui: {
        createView: { fieldMode: 'hidden' },
        itemView: { fieldMode: 'hidden' }
      }
    }),
    salePercentage: virtual({
      field: graphql.field({
        type: graphql.Int,
        resolve(item, args, context) {
          let salePercentage;
          let variant = item as any;
          let price = getPrice(variant);
          salePercentage = Math.round(((variant.regularPrice - price) / variant.regularPrice) * 100);
          return salePercentage;
        },
      }),
      ui: {
        createView: { fieldMode: 'hidden' },
        listView: { fieldMode: 'hidden' },
        itemView: { fieldMode: 'hidden' }
      }
    }),
    length: float({ validation: { isRequired: false } }),
    width: float({ validation: { isRequired: false } }),
    height: float({ validation: { isRequired: false } }),
    weight: float({ validation: { isRequired: true } }),
    stock: relationship({
      ref: 'Stock.variant',
      ui: {
        createView: { fieldMode: 'hidden' },
        // displayMode: 'cards',
        // cardFields: ['stockQuantity', 'dateOfPurchase'],
        // inlineCreate: { fields: ['stockQuantity', 'dateOfPurchase'] },
        // inlineEdit: { fields: ['stockQuantity', 'dateOfPurchase'] },
        // inlineConnect: false,
        // linkToItem: true
      }
    })
    // packageLength: integer({ validation: { isRequired: true } }),
    // packageWidth: integer({ validation: { isRequired: true } }),
    // packageHeight: integer({ validation: { isRequired: true } }),
  },
});